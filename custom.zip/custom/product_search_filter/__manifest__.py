{
    'name': 'product_search_filter',
    'version': '0.1',
    'description': 'Modifications module product',
    'category': 'Uncategorized',
    'author': 'Oci',
    'depends': ['base','product'],
    'data': [

    ],
    'installable': True,
    'application': True,
}
