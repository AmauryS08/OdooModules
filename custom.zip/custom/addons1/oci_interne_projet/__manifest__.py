{
    'name': 'Oci interne projet',
    'version': '0.1',
    'summary': 'Modification du module projet',
    'description': 'Modification du module projet afin de correspondre aux besoins en interne',
    'category': 'Uncategorized',
    'author': 'Groupe OCI',
    'website': 'www.oci.fr',
    'depends': ['project'],
    'data': [
        'views/oci_project.xml',
        'views/oci_crm.xml'
    ],
    'installable': True,
    'auto_install': False
}
