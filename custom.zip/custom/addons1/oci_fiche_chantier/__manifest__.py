{
    'name': 'Fiche chantier',
    'version': '0.1',
    'summary': 'questionnaire pour employée',
    'description': 'Questionnaire à remplir par les employée à chaque nouveau chantier',
    'category': 'Uncategorized',
    'author': 'Groupe OCI',
    'website': 'oci.fr',
    'depends': ['hr'],
    'installable': True,
    'auto_install': False
}
