{
    'name': 'customcolors',
    'version': '0.01',
    'description': 'colors changer',
    'category': 'Uncategorized',
    'author': 'oci',
    'depends': ['web','base'],
    'data': [
        'views/colorchanger.xml',
        'views/res_config_settings_views.xml'
    ],
    'installable': True,
}
