{
    'name': 'oci_sale_order_state',
    'version': '0.1',
    'description': 'Modifications des états du module sale',
    'category': 'Uncategorized',
    'author': 'OCI',
    'depends': ['base','sale'],
    'data': [
        'views/inherited_invoice_view.xml'

    ],
    'installable': True,
    'application': True,
}
