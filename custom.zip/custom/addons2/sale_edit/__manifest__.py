{
    'name': 'sale_edit',
    'version': '0.2',
    'description': 'Modifications module vente et service sur site',
    'category': 'Uncategorized',
    'author': 'OCI',
    'depends': ['base','account','sale'],
    'data': [
    ],
    'installable': True,
    'application': True,
}
